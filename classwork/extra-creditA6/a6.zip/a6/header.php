
<?php echo '
<head>
  <meta charset="utf-8">
  <title>New York | Most Populous City</title>
  <!-- Latest compiled and minified CSS -->


  <!-- JQuery -->
  <script src= "https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <!-- Popper JS --> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>


<!-- Bootstrap Min CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

         <!-- Fonts --> 
		 
		 <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Marcellus+SC" />
		 	
			<!-- Body Fonts Carcellus -->
		 <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans" />

	

		 
		 
	 	 <link rel="stylesheet" type="text/css" href="styles.css" media="screen" />
<header>
 
 
	<!-- Navbar -->
 <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="index.php">New York City</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  
  <div class="collapse navbar-collapse" id="navbarText">
   
	<!-- Right Side Nav Bar -->
	<ul class="navbar-nav ml-auto">
	
	<!-- Manhattan -->
    <li class="nav-item">
     <a class="nav-link" href="manhattan.php">Manhattan <span class="sr-only"></span></a>
    </li>
	
	<!--Brooklyn-->
	
    <li class="nav-item">
     <a class="nav-link" href="brooklyn.php">Brooklyn <span class="sr-only"></span></a>
    </li>
	
<!--Queens-->
 <li class="nav-item">
     <a class="nav-link" href="queens.php">Queens <span class="sr-only"></span></a>
    </li>
	<!--Bronx-->
	
	 <li class="nav-item">
     <a class="nav-link" href="bronx.php">Bronx <span class="sr-only"></span></a>
    </li>
	
	<!-- Staten Island -->
	 <li class="nav-item">
     <a class="nav-link" href="staten-island.php">Staten Island <span class="sr-only"></span></a>
    </li>
	
  </ul>
  </div> <!-- ./ navbar collapse -->
</nav>
  </header>
</head>

<body>
<div class = "container">
<div class = "background">
  

'

?>