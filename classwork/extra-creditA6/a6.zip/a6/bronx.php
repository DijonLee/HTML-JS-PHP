<!DOCTYPE html>

<html>
  <?php include 'includes.php'; ?>
		 <header>

 
 
	<!-- Navbar -->
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">New York City</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  
  <div class="collapse navbar-collapse" id="navbarText">
   
	<!-- Right Side Nav Bar -->
	<ul class="navbar-nav ml-auto">
	
	<!-- Manhattan -->
    <li class="nav-item">
     <a class="nav-link" href="manhattan.php">Manhattan <span class="sr-only"></span></a>
    </li>
	
	<!--Brooklyn-->
	
    <li class="nav-item">
     <a class="nav-link" href="brooklyn.php">Brooklyn <span class="sr-only"></span></a>
    </li>
	
<!--Queens-->
 <li class="nav-item">
     <a class="nav-link" href="queens.php">Queens <span class="sr-only"></span></a>
    </li>
	<!--Bronx-->
	
	 <li class="nav-item">
     <a class="nav-link active" href="bronx.php">Bronx <span class="sr-only"></span></a>
    </li>
	
	<!-- Staten Island -->
	 <li class="nav-item">
     <a class="nav-link" href="staten-island.php">Staten Island <span class="sr-only"></span></a>
    </li>
	
  </ul>
  </div> <!-- ./ navbar collapse -->
</nav>
  </header>
</head>

<body>
<div class = "container">
  


  <main>
<hr>
      <h2 class ="city-name">The Bronx</h2>
	  <hr>

 


    <section class = "top-geo">
	     <img src="images/bronx.jpg" alt="Bronx Grand Concourse">
      <h3>Geography</h3>
      <p>The Bronx is the northernmost of the five boroughs of New York City. Coextensive with Bronx County, it was the last of the 62 counties of New York State to be incorporated. Located north of Manhattan and Queens, and south of Westchester County, the Bronx is the only borough that is located primarily on the mainland (a very small portion of Manhattan, the Marble Hill neighborhood, is physically located on the mainland, because of the rerouting of the Harlem River in 1897). The Bronx’s population is 1,385,108 according to the 2010 United States Census. The borough has a land area of 42 square miles, making it the fourth-largest in land area of the five boroughs, the fourth most populated, and the third-highest in population density.</p>
    </section>

    <section>
      <h3>Characteristics</h3>
      <p>The Bronx is divided by the Bronx River into a hillier section in the west, closer to Manhattan, and the flatter eastern section, closer to Long Island. Technically, the West Bronx is divided from the East Bronx by Jerome Avenue—the continuation of Manhattan's Fifth Avenue—making the West Bronx roughly one-eighth the size of the East Bronx. The West Bronx was annexed to New York City (then largely confined to Manhattan) in 1874, and the areas east of the Bronx River were annexed in 1895. The Bronx first assumed a distinct legal identity when it became a borough of Greater New York in 1898. Bronx County, with the same boundaries as the borough, was separated from New York County (afterwards coextensive with the Borough of Manhattan) as of January 1, 1914.</p>
    </section>

  </main>

  <footer>
    <a href="staten-island.php">Read about Staten Island, New York</a>
  </footer>

</body>
</html>