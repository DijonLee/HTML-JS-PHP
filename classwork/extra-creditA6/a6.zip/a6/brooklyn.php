
<!DOCTYPE html>

<html>

  <?php include 'includes.php'; ?>
 		 <header>

 
	<!-- Navbar -->
 <nav class="navbar navbar-expand-lg navbar-dark bg-light">
  <a class="navbar-brand" href="index.php">New York City</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  
  <div class="collapse navbar-collapse" id="navbarText">
   
	<!-- Right Side Nav Bar -->
	<ul class="navbar-nav ml-auto">
	
	<!-- Manhattan -->
    <li class="nav-item">
     <a class="nav-link" href="manhattan.php">Manhattan <span class="sr-only"></span></a>
    </li>
	
	<!--Brooklyn-->
	
    <li class="nav-item">
     <a class="nav-link active" href="brooklyn.php">Brooklyn <span class="sr-only"></span></a>
    </li>
	
<!--Queens-->
 <li class="nav-item">
     <a class="nav-link" href="queens.php">Queens <span class="sr-only"></span></a>
    </li>
	<!--Bronx-->
	
	 <li class="nav-item">
     <a class="nav-link" href="bronx.php">Bronx <span class="sr-only"></span></a>
    </li>
	
	<!-- Staten Island -->
	 <li class="nav-item">
     <a class="nav-link" href="staten-island.php">Staten Island <span class="sr-only"></span></a>
    </li>
	
  </ul>
  </div> <!-- ./ navbar collapse -->
</nav>
  </header>
</head>

<body>
<div class = "container">
  


  <main>

	<hr>
	
      <h2 class ="city-name"> Brooklyn</h2>
	  <hr>


    <section>
	
      <img src="images/brooklyn.jpg" alt="Brooklyn Bridge"class ="float-left"></a>
      <h3>Geography</h3>
	  
      <p>Brooklyn is the most populous of New York City’s five boroughs, with about 2.5 million people, and the second-largest in area. Since 1896, Brooklyn has had the same boundaries as Kings County, which is now the most populous county in New York and the second-most densely populated county in the United States, after New York County (Manhattan). It is also the westernmost county on Long Island. Today, if it were an independent city, Brooklyn would rank as the fourth most populous city in the U.S., behind only the other boroughs of New York City combined, Los Angeles, and Chicago.</p>
    </section>

    <section>
		  

      <h3>Characteristics</h3>
	  
      <p>Brooklyn was an independent city until January 1, 1898 when, according to the Charter of “Greater New York,” Brooklyn was consolidated with the other boroughs to form the modern “City of New York.” It continues to maintain a distinct culture. Many Brooklyn neighborhoods are ethnic enclaves where particular ethnic groups and cultures predominate. Brooklyn’s official motto is Eendraght Maeckt Maght. Written in early modern Dutch, it is translated, “In unity, there is strength.” The motto is displayed on the borough seal and flag, which also feature a young robed woman bearing fasces, a traditional emblem of Republicanism. Brooklyn’s official colors are blue and gold.</p>
    </section>

  </main>

  <footer>
    <a href="queens.php">Read about Queens, New York</a>
  </footer>

</body>
</html>