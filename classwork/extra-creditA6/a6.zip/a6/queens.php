<!DOCTYPE html>

<html>

  <?php include 'includes.php'; ?>
		 <header>


	<!-- Navbar -->
 <nav class="navbar navbar-expand-lg navbar-dark bg-light">
  <a class="navbar-brand" href="index.php">New York City</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  
  <div class="collapse navbar-collapse" id="navbarText">
   
	<!-- Right Side Nav Bar -->
	<ul class="navbar-nav ml-auto">
	
	<!-- Manhattan -->
    <li class="nav-item">
     <a class="nav-link" href="manhattan.php">Manhattan <span class="sr-only"></span></a>
    </li>
	
	<!--Brooklyn-->
	
    <li class="nav-item">
     <a class="nav-link" href="brooklyn.php">Brooklyn <span class="sr-only"></span></a>
    </li>
	
<!--Queens-->
 <li class="nav-item">
     <a class="nav-link active" href="queens.php">Queens <span class="sr-only"></span></a>
    </li>
	<!--Bronx-->
	
	 <li class="nav-item">
     <a class="nav-link" href="bronx.php">Bronx <span class="sr-only"></span></a>
    </li>
	
	<!-- Staten Island -->
	 <li class="nav-item">
     <a class="nav-link" href="staten-island.php">Staten Island <span class="sr-only"></span></a>
    </li>
	
  </ul>
  </div> <!-- ./ navbar collapse -->
</nav>
  </header>
</head>
  
<body>
<div class = "container">

  <main>

	<hr>
      <h2 class ="city-name">Queens</h2>
	  <hr>

      

    <section>
	<img src="images/queens.jpg" alt="Queens Unisphere">
      <h3>Geography</h3>
	  
      <p>Queens is the easternmost of the five boroughs of <a href="index.php" title="Go back to home page">New York City</a>, the largest in area, and the <a href="index.php#population">second-largest in population</a>. The borough of Queens has been coterminous with Queens County since 1899. The county is now the second most populous county in New York State, as well as the fourth-most densely populated county in the United States. Queens (and Brooklyn) sit on the west end of geographic Long Island. Queens is the most ethnically diverse urban area in the world with a population of over 2.2 million, 48% of whom are foreign-born, representing over 100 different nations and speaking over 138 different languages.</p>
    </section>

    <section>
      <h3>Characteristics</h3>
      <p>If each New York City borough were an independent city, Queens would be America’s fourth most populous city, after Los Angeles, Chicago, and Brooklyn. Queens has the second-largest and most diversified economy of all the five boroughs of New York City. The differing character in the neighborhoods of Queens is reflected by its diverse housing stock ranging from high-density apartment buildings, especially prominent in the more urban areas of central and western Queens, such as Astoria, Long Island City and Ridgewood, to large free-standing single-family homes, common in the eastern part of the borough, in neighborhoods that have a more suburban layout like neighboring Nassau County, such as Little Neck, Douglaston and Bayside.</p>
    </section>

  </main>

  <footer>
      <a href="bronx.php">Read about The Bronx, New York</a>
  </footer>

</body>
</html>