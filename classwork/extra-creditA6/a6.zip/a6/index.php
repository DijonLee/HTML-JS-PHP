
<!DOCTYPE html>

<html>

<?php include 'includes.php'; ?>

<header>
	<!-- Navbar -->
 <nav class="navbar navbar-expand-lg navbar-dark bg-light">
  <a class="navbar-brand" href="index.php">New York City</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  
  <div class="collapse navbar-collapse" id="navbarText">
   
	<!-- Right Side Nav Bar -->
	<ul class="navbar-nav ml-auto">
	
	<!-- Manhattan -->
    <li class="nav-item">
     <a class="nav-link" href="manhattan.php">Manhattan <span class="sr-only"></span></a>
    </li>
	
	<!--Brooklyn-->
	
    <li class="nav-item">
     <a class="nav-link" href="brooklyn.php">Brooklyn <span class="sr-only"></span></a>
    </li>
	
<!--Queens-->
 <li class="nav-item">
     <a class="nav-link" href="queens.php">Queens <span class="sr-only"></span></a>
    </li>
	<!--Bronx-->
	
	 <li class="nav-item">
     <a class="nav-link" href="bronx.php">Bronx <span class="sr-only"></span></a>
    </li>
	
	<!-- Staten Island -->
	 <li class="nav-item">
     <a class="nav-link" href="staten-island.php">Staten Island <span class="sr-only"></span></a>
    </li>
	
  </ul>
  </div> <!-- ./ navbar collapse -->
</nav>
  </header>
</head>

<body>
<div class = "container">
  
  <main>

    <section>
		  <hr />

      <h2>Introduction</h2>
	  <hr>
      <p>New York is the <a href="#population">most populous city</a> in the United States and the center of the New York Metropolitan Area, one of the most populous urban agglomerations in the world. The city is referred to as New York City or the City of New York to distinguish it from the State of New York, of which it is a part. A global power city, New York exerts a significant impact upon commerce, finance, media, art, fashion, research, technology, education, and entertainment. The home of the United Nations Headquarters, New York is an important center for international diplomacy and has been described as the cultural capital of the world.</p>
    </section>

    <section>
		<hr>

      <h2>About</h2>
	  
      <p>Located on one of the world's largest natural harbors, New York City consists of five boroughs, each of which is a county of New York State. The five boroughs—The Bronx, Brooklyn, Manhattan, Queens, and Staten Island—were consolidated into a single city in 1898. With a census-estimated 2012 population of 8,336,697 distributed over a land area of just 302.64 square miles, New York is the most densely populated major city in the United States. As many as 800 languages are spoken in New York, making it the most linguistically diverse city in the world. The New York Metropolitan Area's population is the United States’ largest, with 18.9 million people distributed over 6,720 square miles, and is also part of the most populous combined statistical area in the United States, containing 22.2 million people as of 2011.</p>
    </section>
	<hr>

    <section>
      <h2>History</h2>
      <p>New York traces its roots to its 1624 founding as a trading post by colonists of the Dutch Republic and was named New Amsterdam in 1626. The city and its surroundings came under English control in 1664 and were renamed New York after King Charles II of England granted the lands to his brother, the Duke of York. New York served as the capital of the United States from 1785 until 1790. It has been the country’s largest city since 1790. The Statue of Liberty greeted millions of immigrants as they came to America by ship in the late 19th and early 20th centuries and is a globally recognized symbol of the United States and its democracy.</p>
    </section>
  </main>
	  <hr />

  <section class ="bot-table">
    <h2 class> Population</h2>
    <table border>
      <tr>
        <th>Borough</th>
        <th>Population</th>
        <th>Land Area</th>
      </tr>
      <tr>
        <td>Manhattan</td>
        <td>1,619,090</td>
        <td>23 sq. miles</td>
      </tr>
      <tr>
        <td>Brooklyn</td>
        <td>2,565,635</td>
        <td>71 sq. miles</td>
      </tr>
      <tr>
        <td>Queens</td>
        <td>2,272,771</td>
        <td>109 sq. miles</td>
      </tr>
      <tr>
        <td>The Bronx</td>
        <td>1,408,473</td>
        <td>42 sq. miles</td>
      </tr>
      <tr>
        <td>Staten Island</td>
        <td>470,728</td>
        <td>58 sq. miles</td>
      </tr>
    </table>
  </section>
    
  <footer>
    <a href="manhattan.php">Read about Manhattan, New York</a>
  </footer>
</div> <!-- ./Container -->
</body> 
</html>