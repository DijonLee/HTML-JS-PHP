<!DOCTYPE html>

<html>

<?php include 'includes.php'; ?>
 		 <header>

 
	<!-- Navbar -->
 <nav class="navbar navbar-expand-lg navbar-dark bg-light">
  <a class="navbar-brand" href="index.php">New York City</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  
  <div class="collapse navbar-collapse" id="navbarText">
   
	<!-- Right Side Nav Bar -->
	<ul class="navbar-nav ml-auto">
	
	<!-- Manhattan -->
    <li class="nav-item">
     <a class="nav-link active" href="manhattan.php">Manhattan <span class="sr-only"></span></a>
    </li>
	
	<!--Brooklyn-->
	
    <li class="nav-item">
     <a class="nav-link" href="brooklyn.php">Brooklyn <span class="sr-only"></span></a>
    </li>
	
<!--Queens-->
 <li class="nav-item">
     <a class="nav-link" href="queens.php">Queens <span class="sr-only"></span></a>
    </li>
	<!--Bronx-->
	
	 <li class="nav-item">
     <a class="nav-link" href="bronx.php">Bronx <span class="sr-only"></span></a>
    </li>
	
	<!-- Staten Island -->
	 <li class="nav-item">
     <a class="nav-link" href="staten-island.php">Staten Island <span class="sr-only"></span></a>
    </li>
	
  </ul>
  </div> <!-- ./ navbar collapse -->
</nav>
  </header>
</head>

<body>
<div class = "container">
  



  

 

  <main>

	<hr>
      <h2 class ="city-name">Manhattan</h2>

     
	  <hr>

    <section>
	 <img src="images/manhattan.jpg" alt="Landscape view of Manhattan at night">
      <h3>Geography</h3>
      <p>Manhattan is one of the five boroughs of <a href="index.php">New York City</a>, geographically the smallest but also the most densely populated in the city. Located primarily on the island of Manhattan at the mouth of the Hudson River, the borough is conterminous with New York County, an original county of the U.S. state of New York. The borough and county consist of Manhattan Island and several small adjacent islands: Roosevelt Island, Randall’s Island, Wards Island, Governors Island, Liberty Island, part of Ellis Island, Mill Rock, and U Thant Island; as well as Marble Hill, a small area on the mainland bordering the Bronx. The City of New York originated at the southern tip of Manhattan and expanded northward.</p>
	  <br>
    </section>
    <section>
	
      <h3>Characteristics</h3>
      <p>New York County is the most densely populated county in the United States and is one of the most densely populated areas in the world, with a 2010 population of 1,585,873 living in a land area of 22.96 square miles, or 69,464 residents per square mile, more dense than any individual American city. It is also one of the wealthiest counties in the United States, with a 2005 per capita income above $100,000. Manhattan is the third-largest of New York’s five boroughs in population, after Brooklyn and Queens, and it is the smallest borough in land area.</p>
    </section>

  </main>

  <footer>
    <a href="brooklyn.php">Read about Brooklyn, New York</a>
  </footer>
  <script>
  </script>

</body>
</html>